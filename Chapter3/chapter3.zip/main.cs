using System;
using System.Text;
namespace Chapter3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Employee emp1 = new Employee();
            // emp1.TaoHopDong();
            // ParttimeEmployee emp2 = new ParttimeEmployee();
            // emp2.TaoHopDong();

        }
    }
}