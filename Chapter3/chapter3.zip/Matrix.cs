using System;

namespace Chapter3
{
    class Matrix
    {
        private int row, column;
        private int[,] matrx = new int[100, 100];
        public static Matrix operator +(Matrix a, Matrix b)
        {
            Matrix result = new Matrix();
            if (!matrixCheck(a, b))
            {
                return result;

            }
            for (int i = 0; i < a.row; i++)
                for (int j = 0; j < a.column; j++)
                    result.matrx[i, j] = a.matrx[i, j] + b.matrx[i, j];
            return result;
        }
        public static Matrix operator -(Matrix a, Matrix b)
        {
            Matrix result = new Matrix();
            if (!matrixCheck(a, b))
            {
                return result;

            }
            for (int i = 0; i < a.row; i++)
                for (int j = 0; j < a.column; j++)
                    result.matrx[i, j] = a.matrx[i, j] - b.matrx[i, j];
            return result;
        }
        public static Matrix operator *(Matrix a, int b)
        {
            Matrix result = new Matrix();
            for (int i = 0; i < a.row; i++)
                for (int j = 0; j < a.column; j++)
                    result.matrx[i, j] = a.matrx[i, j] * b;
            return result;
        }
        public static Matrix operator *(Matrix a, Matrix b)
        {
            Matrix result = new Matrix();
            if (!multiableCheck(a, b))
            {
                return result;

            }
            if (a.row == b.column){
                Matrix temp = a;
                a = b;
                b = temp;
            }
            for (int i = 0; i < a.row; i++)
                for (int j = 0; j < b.column; j++)
                    result.matrx[i, j] = a.matrx[i,j] * b.matrx[i,j];
            return result;
        }
        public static bool matrixCheck(Matrix a, Matrix b) => a.row == b.row && a.column == b.column;
        public static bool multiableCheck(Matrix a, Matrix b) => a.row == b.column || a.column == b.row;
    }
}
